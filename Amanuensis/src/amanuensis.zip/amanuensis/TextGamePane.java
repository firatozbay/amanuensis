/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package amanuensis;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.util.ArrayList;
import javax.swing.JTabbedPane;

/**
 *
 * @author Furatto
 */
public class TextGamePane extends JTabbedPane implements Pressable{
   
    CardLayout c;
    
    //ArrayList<JLabel> l;
    
    ArrayList<TabContent> contents;
    int screenH;
    int screenW;
    
    
    float laneNo;
    int activeTab;
    
    FieldModel fm;
    boolean isGameOver; 
    
    
    public TextGamePane(FieldModel fm, int screenW, int screenH)
    {
        setLayout(new BorderLayout());
        
        this.fm     = fm;
        
        contents    = new ArrayList<TabContent>();
        //l           = new ArrayList<JLabel>();
        
        c           = new CardLayout();
        
        
        activeTab   = 0;
        laneNo      = 0;
        this.screenW = screenW;
        this.screenH = screenH;
        isGameOver = false;
        
        //c.addLayoutComponent("s", s);
        
        for(int i = 0; i < 4; i++)
        {
            contents.add(new TabContent());
            addTab("<html><body leftmargin=15 topmargin=8 marginwidth=15 marginheight=5>Empty</body></html>", contents.get(i));
        }
        
        
        setSize(screenW,screenH /2);
        updateUI();
       
        
        this.setFocusable( true);
    }
    
    @Override
public void update(Integer n)
    {
        if( isGameOver)
        {
        }
        else
        {
            if( contents.get(0).buildingToGo != -1 && contents.get(0).isBuilt())
            {
                boolean weAreFinishedHere = false;

                if(n == 38)
                {
                    laneNo++;
                    laneNo = (laneNo + 3)%3;
                    notifyField();
                    weAreFinishedHere = true;
                }

                else if (n == 40)
                {
                    laneNo--;
                    laneNo = (laneNo + 3)%3;
                    notifyField();
                    weAreFinishedHere = true;
                }

                //System.out.println(n);
                if( n <= 52 && n >= 47 && !weAreFinishedHere)
                    activeTab = n - 49;
                else if(!weAreFinishedHere)
                {
                    contents.get(activeTab).update(n);
                }

                setActive();




                if( !weAreFinishedHere && contents.get(activeTab).b.selected() >= 0){


                    setTitleAt( activeTab, "<html><body leftmargin=15 topmargin=8 marginwidth=15 marginheight=5>"+contents.get(activeTab).b.bags.get(contents.get(activeTab).b.selected()).getString() +"</body></html>");//
                    contents.get(activeTab).building();

                    notifyField();

                    if ( contents.get(activeTab).isBuilt())
                    {
                        notifyField();
                    }
                }
           }
           else
            {
                activeTab = 0;
                contents.get(activeTab).update(n);
                setActive();
                if(  contents.get(activeTab).b.selected() >= 0){


                    setTitleAt( activeTab, "<html><body leftmargin=15 topmargin=8 marginwidth=15 marginheight=5>"+contents.get(activeTab).b.bags.get(contents.get(activeTab).b.selected()).getString() +"</body></html>");//
                    contents.get(activeTab).building();

                    notifyField();

                    if ( contents.get(activeTab).isBuilt())
                    {
                        notifyField();
                    }
                }

            }




            repaint();
        }
    }
    
    public void setActive()
    {
        setSelectedIndex(activeTab);
        
    }
    
    public void notifyField()
    {
        if(contents.get(activeTab).getUnitToGo() >= 0)
            fm.notifyUnit( contents.get(activeTab).unitToGo);
        contents.get(activeTab).unitToGo = -1;
        if(contents.get(activeTab).isBuilt())
            fm.notifyBuilding(contents.get(activeTab).buildingToGo, activeTab);
        //contents.get(activeTab).isBuilt = false;
        fm.notifyLane(laneNo);
    }
    
    public void falls( int activeT)
    {
        activeTab = activeT;
        contents.get( activeT).destroy();
        updateUI();
        repaint();
    }
    
    public void gameIsOver()
    {
        isGameOver = true;
    }
    
}
