/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package amanuensis;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

/**
 *
 * @author Magus
 */
public class Cavalry extends LivingUnit{
    
     final static double DX = 6;
     final static double RANGE = 55;
     final static double SIZE = 45;
     final static int DAMAGE = 30;
     final static int BASE_HP = 250;
     final static int HIT_B = 40;
     final static int MAX_CHARGE_COUNT = 1000;
     final static int CHARGE_MOD = 15;
     
     // priority ( higher is better) 
     final static int CAN_CRUSH = 100;// can remove large chunks of damage at once
     final static int LOW_HP = 4; // if hp is lower than or equal to 50
     final static int IS_PIKEMAN = 300; // if it is pikeman
     final static int IS_SABOTEUR = -100; // never attack one wont do any good
     final static int IS_CAVALRY = 2; // Should eliminate  before the next charge
     final static int IS_TREB = 1; // dangerous 
     final static int IS_ARCHER = 0;
     final static int IS_SWORDSMAN = 0;
     final static int IS_KEEP = 0;
     final static int IS_WALL = 0;
     final static int IS_BUILDING = 0;
     
     int hitBreak; 
     int chargeCounter;
     int maxCharge;    
     boolean isSupressed;
     int priorityCount;

    public Cavalry(Lane lane, boolean isHost, int level) {
        
        super(lane, isHost, level);
        setLevel( level);
        hitBreak = HIT_B;
        hP = BASE_HP;
        range = RANGE;
        size = SIZE;
        state = 0;
        damage = DAMAGE + level*10;
        size_modifier = lane.getMod();
        isSupressed = false;
        maxCharge = (int)(MAX_CHARGE_COUNT / lane.getSpM());
        chargeCounter = maxCharge;
        
        if( isHost)
        {
             setLaneLoc( lane.getStart());
             super.dx = DX*lane.speedModifier;
        }
          
         else
        {
            setLaneLoc( lane.getEnd());
            super.dx = -DX*lane.speedModifier;
        } 
        
    }

    @Override
    public void damagedBy(Unit unit) {
        hP = hP - unit.getDamage();
        if( hP <= 0)
        {
            setState( 2);
            lane.removeUnit( this) ;
        }
    }

    @Override
    public void act() {
        takeTarget();       
        if( state == 0)
            if( !isSupressed)
            {
                move();
                chargeCounter ++;
            }
        if( target != null && state == 1)
        {
            if( chargeCounter >= maxCharge 
                    && hitBreak >= HIT_B/lane.speedModifier 
                )
            {
                charge( target);
                chargeCounter = 0;
                hitBreak = 0;
            }
            else if( hitBreak >= HIT_B/lane.speedModifier)
            {
                target.damagedBy( this);
                hitBreak = 0;
                chargeCounter ++;
            }
            else
                hitBreak ++;    
                chargeCounter ++;
            if(  target.getHP() <= 0)
            {
                target = null;
                setState( 0);
            }
        }  
    }

    @Override
    public void draw(Graphics g) {
        if( state == 0)
        {
            g.setColor(Color.black);
            g.fillOval(((int)(laneLoc*size_modifier - size*size_modifier) ),(int) (y*lane.getYMod() - size*size_modifier), 2*(int)(size*size_modifier ), 2*(int)(size*size_modifier ));
        }
        if( state == 1)
        {
            g.setColor(Color.blue);
            g.fillOval(((int)(laneLoc*size_modifier - size*size_modifier) ),(int) (y*lane.getYMod() - size*size_modifier), 2*(int)(size*size_modifier ), 2*(int)(size*size_modifier ));
            g.setColor(Color.black);
        }
    }

   @Override
    public boolean takeTarget() {
       int loopCount = 0;
       priorityCount = 0;
       int priority = 0;
       ArrayList < Unit> targets = lane.targetsFor(this);
       if( targets.isEmpty())
       {
           state = 0;
           return true;  
       }
       Unit targetC = null;
       for( int i = 0; i < targets.size(); i++)
       {
           priority = 0;
           if( chargeCounter < maxCharge 
               && targets.get(i).getHP() <= damage)
               priority += LOW_HP;
           if( targets.get(i).getClass() == Pikeman.class)
               priority += IS_PIKEMAN;
           if ( targets.get(i).getClass() == Saboteur.class)
               priority += IS_SABOTEUR;
           if ( targets.get(i).getClass() == Cavalry.class)
               priority += IS_CAVALRY;
           if ( targets.get(i).getClass() == Treb.class)
               priority += IS_TREB;
           if ( targets.get(i).getClass() == Swordsman.class)
               priority += IS_SWORDSMAN;
           if ( targets.get(i).getClass() == Keep.class)
               priority += IS_KEEP;
           if ( targets.get(i).getClass() == Wall.class)
               priority += IS_WALL;
           if ( targets.get(i).getClass() == Building.class)
               priority += IS_BUILDING;
           if ( targets.get(i).getClass() == Archer.class)
               priority += IS_ARCHER;
           if( chargeCounter >= maxCharge 
                   && targets.get(i).getHP() <= damage*CHARGE_MOD 
                   && targets.get(i).getHP() > 150)
               priority += CAN_CRUSH;
           if(chargeCounter >= maxCharge 
                   && targets.get(i).getHP() <= damage*CHARGE_MOD 
                   && targets.get(i).getHP() > 250)
               priority += CAN_CRUSH;
           if(chargeCounter >= maxCharge 
                   && targets.get(i).getHP() <= damage*CHARGE_MOD 
                   && targets.get(i).getHP() > 350)
               priority += CAN_CRUSH;
           
           if( targetC == null || priority > priorityCount)
           {
               if( targets.get(i).getHP() > 0)
               {
                 targetC = targets.get(i);
                 state = 1;
               }
           }
           priority = 0;
       }
       target = targetC;
       return true;
    }
    
    public void charge( Unit unit)
    {
        setDamage( damage*CHARGE_MOD);
        unit.damagedBy(this);
        setDamage( DAMAGE + level*10);
    }
    public void isSupressed( boolean a)
    {
        isSupressed = a;
    }
}