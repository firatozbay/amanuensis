/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package amanuensis;

/**
 *
 * @author Magus
 */
public class Keep extends Building{
    
    final static int HIT_P = 4000;
    

    public Keep(Lane lane, boolean isHost, int level) {
        super(lane, isHost, level);
        canAttack = true;
        hP = HIT_P;
    }
    
    public Keep(FieldModel fM, boolean isHost, int level)
    {
        super( fM, isHost, level);
        canAttack = true;
        hP = HIT_P;
    }
  
    @Override
    public void attack()
    {
        target.getLane().addUnit( new Projectile( this , target));
        target.getLane().addUnit( new Projectile( this , target));
        hitBreak = 0;
    }
}
