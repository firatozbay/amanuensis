/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package amanuensis;

import java.awt.Dimension;
import javax.swing.JPanel;

/**
 *
 * @author Magus
 */
public class MainPane extends JPanel implements Pressable, GameStatusListener{
    
    private FieldModel fM;
    private FieldCanvas fC;
    private TextGamePane txt;
    
    int screenH;
    int screenW;
    
    private double speedMod;
    private MyKeyListener key;
    
    private boolean gameIsOver;
    
    public MainPane( int screenW, int screenH, double speedMod)
    {
        super();
        this.screenH = screenH;
        this.screenW = screenW;
        this.speedMod = speedMod;
        
        key = new MyKeyListener(this);
        
        fM = new FieldModel( screenW, screenH/2, speedMod);
        txt = new TextGamePane( fM, screenW, screenH/2);
        fC = new FieldCanvas( fM);
        
        fM.addTextGame( txt);
        addKeyListener(key);
        
        add( fC);
        add( txt);
        
        setFocusable( true);
        
        setPreferredSize( new Dimension(screenW, screenH));     
    }        

    @Override
    public void update(Integer n) {
        txt.update(n);
    }

    @Override
    public void gameIsFinished() {
        gameIsOver = true;
        //popup here
        
    }
}
