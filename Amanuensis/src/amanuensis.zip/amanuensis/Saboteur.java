/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package amanuensis;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

/**
 *
 * @author Magus
 */
public class Saboteur extends LivingUnit{
    
     final static double DX = 5;
     final static double RANGE = 35;
     final static double SIZE = 35;
     final static int DAMAGE = 25;
     final static int BASE_HP = 40;
     final static int HIT_B = 0;
     final static boolean isD0T = true;

    public Saboteur(Lane lane, boolean isHost, int level) {
        super(lane, isHost, level);
         setLevel( level);
         hitBreak = HIT_B;
         super.hP = BASE_HP;
         super.range = RANGE;
         super.size = SIZE;
         super.state = 0;
         super.damage = DAMAGE + level*5;
         super.size_modifier = lane.getMod();
         if( isHost)
        {
             setLaneLoc( lane.getStart());
             super.dx = DX*lane.speedModifier;
        }
          
         else
        {
            setLaneLoc( lane.getEnd());
            super.dx = -DX*lane.speedModifier;
        } 
    }

    @Override
    public void damagedBy(Unit unit) {
            hP = hP - unit.getDamage();
            if( hP <= 0)
            {
                setState( 2);
                lane.addUnit( new Explosion( this));
                lane.removeUnit( this) ;
            } 
    }

    @Override
    public void act() {
        takeTarget(); 
        if( state == 0)
            move();

        if( target != null && state == 1)
        {
            if( hitBreak >= HIT_B/lane.speedModifier)
            {
                lane.addUnit( new Explosion( this));
                lane.removeUnit( this);
                state = 2;
            }
            else
                hitBreak ++;         
            if(  target.getHP() <= 0)
            {
                target = null;
                setState( 0);
            }
        }
        
    }

    @Override
    public void draw(Graphics g) {
        if( state == 0)
        {
            g.setColor(Color.black);
            g.fillOval(((int)(laneLoc*size_modifier - size*size_modifier) ),(int) (y*lane.getYMod() - size*size_modifier), 2*(int)(size*size_modifier ), 2*(int)(size*size_modifier ));
        }
        if( state == 1)
        {
            g.setColor(Color.blue);
            g.fillOval(((int)(laneLoc*size_modifier - size*size_modifier) ),(int) (y*lane.getYMod() - size*size_modifier), 2*(int)(size*size_modifier ), 2*(int)(size*size_modifier ));
            g.setColor(Color.black);
        }
        
    }

    @Override
    public boolean takeTarget() {
       ArrayList < Unit> targets = lane.targetsFor(this);
       if( targets.isEmpty())
       {
           state = 0;
           return true;  
       }
       Unit targetC = null;
       for( int i = 0; i < targets.size(); i++)
       {
           if( targetC == null || targetC.getHP() >= targets.get(i).getHP())
           {
               if( targets.get(i).getHP() > 0)
               {
                 targetC = targets.get(i);
                 state = 1;
               }
           }
       }
       target = targetC;
       return true;
    }
    
    public boolean isDoT()
    {
        return isD0T;
    }
    
}
