/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package amanuensis;

import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.JPanel;

/**
 *
 * @author Furatto
 */
public class TabContent extends JPanel{
    
    BuildingList        b;
    SentenceContainer   s;
    
    boolean             state; 
    int                 unitToGo;
    public double       buildingToGo;   //4 elemanli 10 farkli int degeri
    boolean             isBuilt;
    int                 count;
    boolean             unitReady;
    boolean             buildingIsReady;
    

    
    public TabContent()
    {
        setLayout( new GridLayout());

        
   
        
        b = new BuildingList();
        s = new SentenceContainer();
        
        
        state = false;
        
        count  = 0;
        unitToGo = -1;
        buildingToGo = b.selected();
        
        isBuilt = false;
        add(b);
        count++;
        
        setVisible(true);
        unitReady = s.getState();
        
        
        
    }
    
    public void update(Integer n)
    {
        buildingIsReady = false;
        //unitToGo = -1;
        //buildingToGo = -1;
        //System.out.println( s.getScore());
        
        if(state){
            s.update(n);
            unitReady = s.getState();
            isBuilt = s.getScore()>=4;
        } 
        
        else
        {
            buildingIsReady = true;
            b.update(n);
            buildingToGo = b.selected();
        }
        
        if(isBuilt && unitReady/*&& s.sentences.get(0).allCorrect()*/)
        {
            unitToGo = (int) buildingToGo;
            s.setState( false);
        }
        
    }
    
    public int getUnitToGo()
    {
        return unitToGo;
    }
    
    public double getBuildingToGo()
    {
        return buildingToGo;
    }
    
    public void building(){
        
        state = true;
        
        buildingToGo = b.selected();
        
        
        
        if(count==1){
            s = new SentenceContainer();
            add(s);
            remove(b);
            count++;
            state = true;
        }
        
            
        repaint();
    }
    
    public boolean isBuilt(){
        
        if(s.getScore() >= 4)
        {
            isBuilt = true;
            state = true;
        }
        
        repaint();
        
        return isBuilt;
    }
    
    public void destroy(){
        
      //setLayout( new GridLayout());
        
        //remove(s);
        //remove(b);
        
       // b = new BuildingList();
        //s = new SentenceContainer();
        //state = false;
        //isBuilt = false;
       // unitReady = false;
        //count = 0;
        
        //add(b);
        //s.setScore(0);
        
        //buildingToGo = -1;
        reInit();
        
        updateUI();
        repaint();
    }
    
    public void reInit()
    {
        setLayout( new GridLayout());
        
        remove(s);
        remove(b);
        
        b = new BuildingList();
        s = new SentenceContainer();
        
        
        state = false;
        
        count  = 0;
        unitToGo = -1;
        buildingToGo = b.selected();
        
        isBuilt = false;
        add(b);
        count++;
        
        setVisible(true);
        unitReady = s.getState();
    }
}
