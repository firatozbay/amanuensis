package amanuensis;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JLabel;
//Rules changed: 5 max incorrect tries then reduce 10 letters from completion

public class Letter extends JLabel{
	
	final String allLetters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";	
        final String allNumbers = "0123456789";
        
        boolean color, tried;
	
	char c;
	String s;
        
	public Letter(char c)
	{
            this.c = c;
            color = false;
            this.s = ""+ c;
            setForeground(Color.black);
            this.setText(s);
            updateUI();
            setFont(getFont().deriveFont(32.0f));
	}
	
	public void setColor(boolean color)
	{
            this.color = color;
            tried = true;
            if(color){
                setForeground(Color.green);
        }
            else if(tried)
                    setForeground(Color.red);
            else
                    setForeground(Color.black);
            this.updateUI();
            this.setText(s);
	}
	
	public boolean getColor()
	{
		return color;
	}
	
	public boolean isTrue(char c)
	{
		return c == this.c;
	}
	public int getCharCode()
	{       
            if(c == ' ')
                return 32;
            if(c == ',')
                return 44;
            if(c == '-')
                return 45;
            if(c == '.')
                return 46;
            if(c == '\'')
                return 39;
            if(allLetters.indexOf(c) == -1)
                return allNumbers.indexOf(c) + 48;
            return allLetters.indexOf(c)%26 + 65;
	}
        
        @Override
        public void paintComponent(Graphics g)
        {
            super.paintComponent(g);
        }
}
