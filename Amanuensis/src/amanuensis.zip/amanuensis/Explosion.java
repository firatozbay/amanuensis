/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package amanuensis;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

/**
 *
 * @author Magus
 */
public class Explosion extends Unit{
     final static double RANGE = 200;
     final static double SIZE = 0;
     final static int DAMAGE = 0;
     final static int BASE_HP = 200;
     final static int HIT_B = 0;
     
     boolean flameEffect;
     boolean isDoT;
     int boomCount;
     int maxGraphicBoomCount;
     int graphicBoomCount;
     int boomInterval;
     int intervalCount;
     /*
        0 alive!
        1 dead...
     */

    public Explosion(Lane lane, boolean isHost, int level) {
        super(lane, isHost, level);
    }
    
    public Explosion( Projectile unit)
    {
        super( unit.getLane(), unit.isHost(), unit.getLevel());
        super.state = 0;
        super.size_modifier = lane.getMod();       
        setLaneLoc( unit.getLaneLoc());
        y = lane.getY(laneLoc);
        damage = unit.getDamage();
        boomInterval = 1;
        intervalCount = boomInterval;
        
        if( unit.isExplosive())
        {
            boomCount = 1;
            size = 100;
            range = 100;
            flameEffect = false;
            graphicBoomCount = 1;
            maxGraphicBoomCount = 1;
        }
        else
        {
            boomCount = 1;
            size = 120;
            range = 100;
            flameEffect = false;
            graphicBoomCount = 1;
            maxGraphicBoomCount = 1;
        }
    }
    public Explosion ( Saboteur unit)
    {
        super( unit.getLane(), unit.isHost(), unit.getLevel());
        super.state = 0;
        super.size_modifier = lane.getMod();       
        setLaneLoc( unit.getLaneLoc());
        y = lane.getY(laneLoc);
        damage = unit.getDamage();
        boomInterval = (int)(2 / lane.getSpM());
        intervalCount = boomInterval;
        
        if( !unit.isDoT())
        {
            boomCount = 1;
            size = 120;
            range = 100;
            flameEffect = false;
            graphicBoomCount = 1;
            maxGraphicBoomCount = 1;
        }
        else
        {
            boomCount = 15;
            size = 170;
            range = 150;
            flameEffect = true;  
            graphicBoomCount = 2;
            maxGraphicBoomCount = 2;
        }
    }

    @Override
    public void damagedBy(Unit unit) {
    }

    @Override
    public void act() {
        if( state == 1 )
        {
          lane.removeUnit( this);  
        }
        if ( state == 0 
                && boomInterval == intervalCount)
        {
            ArrayList< Unit> targets = lane.targetsFor(this);
            for( int i = 0; i < targets.size(); i++)
            {
                targets.get(i).damagedBy(this);
            }
            boomCount --;
            intervalCount = 0;
            if( boomCount <= 0)
            {
                state = 1;
            }
        }
        intervalCount ++;
    }

    @Override
    public void draw(Graphics g) {
        Color eColor = new Color( 123, 132, 212); 
        
        if( graphicBoomCount >=  maxGraphicBoomCount )
        {
            g.setColor(eColor);
            g.fillOval(((int)(laneLoc*size_modifier - size*size_modifier) ),(int) (y*lane.getYMod() - size*size_modifier), 2*(int)(size*size_modifier ), 2*(int)(size*size_modifier ));
            g.setColor(Color.black);
            graphicBoomCount = 0;
        }
        graphicBoomCount ++;
        
        
    }

    @Override
    public boolean takeTarget() {
        return true;
    }
    
    public boolean flameEffect()
    {
        return flameEffect;
    }
}
