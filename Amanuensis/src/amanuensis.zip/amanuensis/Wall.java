/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package amanuensis;

/**
 *
 * @author Magus
 */
public class Wall extends Building{
    
    final static int HIT_P = 6000;
    final static int IDLE_START_COUNT = 500;
    final static int HEALING_MAX_INTERVAL = 200;
    
    private int idleCount;
    private int idleStartCurrent;
    private int healingInterval;
    private int healingCounter;
    
    public Wall(Lane lane, boolean isHost, int level) {
        super(lane, isHost, level);
        canAttack = false;
        hP = HIT_P;
        idleStartCurrent = (int)(IDLE_START_COUNT/lane.getSpM());
        idleCount = idleStartCurrent;
        healingInterval = (int)(HEALING_MAX_INTERVAL/lane.getSpM());
        healingCounter = healingInterval;
    }
    public Wall(FieldModel fM, boolean isHost, int level)
    {
        super( fM, isHost, level);
        canAttack = false;
        hP = HIT_P;
        idleStartCurrent = (int)(IDLE_START_COUNT*lane.getSpM());
        idleCount = idleStartCurrent; 
        healingInterval = (int)(HEALING_MAX_INTERVAL*lane.getSpM());
        healingCounter = healingInterval;
    }
    @Override
    public void damagedBy( Unit unit)
    {
        idleCount = 0;
        hP = hP - unit.getDamage();       
        if( hP <= 0)
        {
            setState( 2);
            lane.removeUnit( this) ;
            if( botLane != null)
                botLane.removeUnit( this);
            if( topLane != null)
               topLane.removeUnit( this);
        }
    }
    
    @Override
    public void act()
    {
        idleCount ++;
        if( idleCount >= idleStartCurrent
                && healingCounter >= healingInterval
                && hP < HIT_P)
        {
            hP = hP + hP/20;
            idleCount = idleStartCurrent;
            healingCounter = 0;
        }
        healingCounter++;
    }
}
