/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amanuensis;

import java.awt.event.*;
import java.util.ArrayList;
/**
 *
 * @author Furatto
 */
public class MyKeyListener implements KeyListener {
    
    ArrayList<Integer> keysDown;
    
    Pressable p;
    
    public MyKeyListener(Pressable p)
    {
        this.p = p;
        
        keysDown = new ArrayList<Integer>();
    }

    @Override
    public void keyPressed(KeyEvent e) 
    {
        System.out.println("dsdasd");
        if(!keysDown.contains(e.getKeyCode()))
            keysDown.add(new Integer(e.getKeyCode()));
        
        //System.out.println(keysDown.get(keysDown.size()-1));
        
        p.update(keysDown.get(keysDown.size()-1));   
    }
    
    @Override
    public void keyReleased(KeyEvent e) {
        
        keysDown.remove(new Integer(e.getKeyCode()));
        
    }
    @Override
    public void keyTyped(KeyEvent e) {}

    
}
