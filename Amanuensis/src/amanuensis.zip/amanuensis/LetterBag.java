package amanuensis;

import java.awt.*;
import javax.swing.*;
import java.util.ArrayList;


public class LetterBag extends JPanel implements Pressable{
        
    Letter[] letters;
    int index;
    Color bordercolor;
    boolean active;
    int wrongTries;
    String str;
    
    public LetterBag(String str, boolean active)
    {
        setLayout(new FlowLayout());
        
        letters = new Letter[str.length()];
        this.active = active;
        this.str = str;
        
        index = 0;
        wrongTries = 0;
        
        bordercolor = Color.BLACK;
        
                
        setBackground(Color.white);

        for(int i = 0; i < str.length(); i++)
        {
            letters[i] = new Letter(str.charAt(i));
            add(letters[i]);
        }
        
        if(active)
            setBorder (BorderFactory.createLineBorder (bordercolor, 3));

        setVisible(true);
    }

    public int atLetter()
    {
        return index;
    }
    
    public void setActive(boolean setActive)
    {
        this.active = setActive;
        
        if(this.active)
            setBorder (BorderFactory.createLineBorder (bordercolor, 3));
    }
    
    public void update( Integer n)
    {
        //for(int i = 0; i < letters.length; i++)
        //System.out.println(letters[i].getCharCode());
        //System.out.print("letterbag" + n + "current" + getCurrent().getCharCode());
        if(!allCorrect()&& getCurrent() != null)
        {
            if( n == getCurrent().getCharCode() )
            {
                nextLetter();
                wrongTries--;
            }
            else if(getCurrent()== null)
            {
                //isOver
            }
            else
            {
                //System.out.println("sen bılırsın");
                wrongTries++;
                
                letters[index].setColor(false);
                
                if(wrongTries >= 5)
                    penalty();
            }
        }
        this.updateUI();
    }
    
    public void nextLetter()
    {
        letters[index].setColor(true);
        
        index++;
        if(allCorrect())
        {
            bordercolor = Color.green;
            setBorder(BorderFactory.createLineBorder(bordercolor, 3));
        }
    }

    public void penalty()
    {
            if( index > 5)
            {
                for( int i = 0; i < 5; i++)
                    letters[index-5+i].setColor(false);
                index = index -5;
            }
            else
            {
                for( int i = 0; i < index; i++)
                    letters[i].setColor(false);
                index = 0;
            }
            
            wrongTries = 0;

    }
    public String getString()
    {
        return str;
    }
    public boolean allCorrect()
    {
        return letters[letters.length-1].getColor();
    }

    public Letter getCurrent()
    {
        if(allCorrect())
            return null;
        return letters[index];
    }

    public String toString()
    {
        String s = "";
        for( int i = 0; i < letters.length; i++ )
        {
            s += letters[i];
        }
        return s;
    }
    
    @Override
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
    }

}
