/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package amanuensis;


/**
 *
 * @author Magus
 */
public class ExplosivesWorkshop extends Building{
    
       final static int HIT_P = 3000;

    public ExplosivesWorkshop(Lane lane, boolean isHost, int level) {
        super(lane, isHost, level);
        canAttack = false;
        hP = HIT_P;
    }
    public ExplosivesWorkshop(FieldModel fM, boolean isHost, int level)
    {
        super( fM, isHost, level);
        canAttack = false;
        hP = HIT_P;
    }

}
