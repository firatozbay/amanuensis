/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package amanuensis;

import java.awt.Dimension;
import javax.swing.JFrame;

/**
 *
 * @author Magus
 */
public class Amanuensis {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        MainPane fM = new MainPane( 1400, 800 ,0.8);
        JFrame frame = new JFrame();
        
         
        frame.add( fM);
        fM.requestFocus();
        
        frame.setSize( new Dimension( 1400, 800));
        frame.setVisible(true);
       
    }
    
}
