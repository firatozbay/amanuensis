/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package amanuensis;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

/**
 *
 * @author Magus
 */
public class Archer extends LivingUnit{
    
    /* 0 move
       1 attack
       2 die   
    */
    
     final static double DX = 3;
     final static double RANGE = 600;
     final static double SIZE = 35;
     final static int DAMAGE = 30;
     final static int BASE_HP = 200;
     final static int HIT_B = 30;
     
     // priority ( higher is better) 
     final static int LOW_HP = 4; // if hp is lower than or equal to 50
     final static int IS_PIKEMAN = 3; // if it is pikeman
     final static int IS_SABOTEUR = 100; // never attack one wont do any good
     final static int IS_CAVALRY = 2; // Should eliminate  before the next charge
     final static int IS_TREB = 0; // cant force-cancel attacks so meaningless, and dmg wont be enough 
     final static int IS_ARCHER = 0;
     final static int IS_SWORDSMAN = 0;
     final static int IS_KEEP = 0;
     final static int IS_WALL = 0;
     final static int IS_BUILDING = 0;
     final static int IS_NEAR = 3;
     
    int priorityCount;

    public Archer(Lane lane, boolean isHost, int level) {
         super(lane, isHost, level);
         setLevel( level);
         hitBreak = HIT_B;
         super.hP = BASE_HP;
         super.range = RANGE;
         super.size = SIZE;
         super.state = 0;
         super.damage = DAMAGE + level*10;
         super.size_modifier = lane.getMod(); 
         
        if( isHost)
        {
             setLaneLoc( lane.getStart());
             super.dx = DX*lane.speedModifier;
        }
          
         else
        {
            setLaneLoc( lane.getEnd());
            super.dx = -DX*lane.speedModifier;
        } 
    }

    @Override
    public void damagedBy(Unit unit) {
        
        hP = hP - unit.getDamage();
        if( hP <= 0)
        {
            setState( 2);
            lane.removeUnit( this) ;
        }   
    }

    @Override
    public void act() {
         takeTarget(); 
        if( state == 0)
            move();
        if( target != null && state == 1)
        {
            if( hitBreak >= HIT_B/lane.speedModifier)
            {
                lane.addUnit( new Projectile( this));
                hitBreak = 0;
            }
            else
                hitBreak ++;         
            if(  target.getHP() <= 0)
            {
                target = null;
                setState( 0);
            }
        }  
    }

    @Override
    public void draw(Graphics g) {
        if( state == 0)
        {
            g.setColor(Color.black);
            g.fillOval(((int)(laneLoc*size_modifier - size*size_modifier) ),(int) (y*lane.getYMod() - size*size_modifier), 2*(int)(size*size_modifier ), 2*(int)(size*size_modifier ));
        }
        if( state == 1)
        {
            g.setColor(Color.green);
            g.fillOval(((int)(laneLoc*size_modifier - size*size_modifier) ),(int) (y*lane.getYMod() - size*size_modifier), 2*(int)(size*size_modifier ), 2*(int)(size*size_modifier ));
            g.setColor(Color.black);
        }
    }

   @Override
    public boolean takeTarget() {
       priorityCount = 0;
       int priority = 0;
       ArrayList < Unit> targets = lane.targetsFor(this);
       if( targets.isEmpty())
       {
           state = 0;
           return true;  
       }
       Unit targetC = null;
       for( int i = 0; i < targets.size(); i++)
       {
           priority = 0;
           if( targets.get(i).getHP() <= damage)
               priority += LOW_HP;
           if( targets.get(i).getClass() == Pikeman.class)
               priority += IS_PIKEMAN;
           if ( targets.get(i).getClass() == Saboteur.class)
               priority += IS_SABOTEUR;
           if ( targets.get(i).getClass() == Cavalry.class)
               priority += IS_CAVALRY;
           if ( targets.get(i).getClass() == Treb.class)
               priority += IS_TREB;
           if ( targets.get(i).getClass() == Swordsman.class)
               priority += IS_SWORDSMAN;
           if ( targets.get(i).getClass() == Keep.class)
               priority += IS_KEEP;
           if ( targets.get(i).getClass() == Wall.class)
               priority += IS_WALL;
           if ( targets.get(i).getClass() == Building.class)
               priority += IS_BUILDING;
           if ( targets.get(i).getClass() == Archer.class)
               priority += IS_ARCHER;
           if( targetC != null && Math.abs(targets.get(i).getLaneLoc() - laneLoc) < Math.abs(targetC.getLaneLoc() - laneLoc))
               priority = IS_NEAR;
           
           if( targetC == null || priority > priorityCount)
           {
               if( targets.get(i).getHP() > 0)
               {
                 targetC = targets.get(i);
                 state = 1;
               }
           }
           priority = 0;
       }
       target = targetC;
       return true;
    }
    
}
