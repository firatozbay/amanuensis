/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package amanuensis;

import java.awt.Graphics;
import java.awt.image.BufferedImage;


/**
 *
 * @author Magus
 */
public class Armory extends Building{
    
       final static int HIT_P = 3000;
       static BufferedImage img;
       static ImageLoader loader;
       static ImageModificator mod;

    public Armory(Lane lane, boolean isHost, int level)  {
        super(lane, isHost, level);
        canAttack = false;
        hP = HIT_P;
        loader = new ImageLoader("res/png_example.png");
        img = loader.getIMG();
        mod = new ImageModificator();
        img = mod.flip(img);
        img = mod.resize(img, 6*size*size_modifier/img.getWidth());

    }
    public Armory(FieldModel fM, boolean isHost, int level) 
    {
        super( fM, isHost, level);
        canAttack = false;
        hP = HIT_P;
        loader = new ImageLoader("res/shapes_squareRed.jpg");
        img = loader.getIMG();
        mod = new ImageModificator();
        img = mod.flip(img);
        img = mod.resize(img, 6*size*size_modifier/img.getWidth());
    }
    
    @Override
    public void draw( Graphics g)
    {
        g.drawImage( img, ((int)(laneLoc*size_modifier - img.getWidth()/2) ),(int) (y*lane.getYMod() - img.getHeight()/2), null);
        g.fillOval(((int)(laneLoc*size_modifier - size*size_modifier) ),(int) (y*lane.getYMod() - size*size_modifier), 2*(int)(size*size_modifier ), 2*(int)(size*size_modifier ));
    }
}
