/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package amanuensis;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

/**
 *
 * @author Magus
 */
public class Treb extends LivingUnit{
    
     final static double DX = 1;
     final static double RANGE = 1200;
     final static double SIZE = 100;
     final static int DAMAGE = 100;
     final static int BASE_HP = 550;
     final static int HIT_B = 100;
     final static int MX_BC = 5;
     
     // priority ( higher is better) 
     final static int LOW_HP = 6; // if hp is lower than or equal to 50
     final static int IS_PIKEMAN = 4; // if it is pikeman
     final static int IS_SABOTEUR = 8; // never attack one wont do any good
     final static int IS_CAVALRY = 2; // Should eliminate  before the next charge
     final static int IS_TREB = 4; // dangerous 
     final static int IS_ARCHER = 1;
     final static int IS_SWORDSMAN = 0;
     final static int IS_KEEP = 0;
     final static int IS_WALL = 0;
     final static int IS_BUILDING = 0;
     final static int IS_NEAR = 6;
     final static int IS_ZERGED = 20;
     final static int IS_NOT_MOVING = 50;
     

     boolean isBurning;
     int burnCount;
     int priorityCount;
     
    public Treb(Lane lane, boolean isHost, int level) {
        super(lane, isHost, level);
        setLevel( level);
         hitBreak = 0;
         super.hP = BASE_HP;
         super.range = RANGE;
         super.size = SIZE;
         super.state = 0;
         super.damage = DAMAGE + level*20;
         super.size_modifier = lane.getMod();
         burnCount = 0;
         if( isHost)
        {
             setLaneLoc( lane.getStart());
             super.dx = DX*lane.speedModifier;
        }
          
         else
        {
            setLaneLoc( lane.getEnd());
            super.dx = -DX*lane.speedModifier;
        } 
    }

    @Override
    public void damagedBy(Unit unit) {
        if( unit.getClass() == Explosion.class 
                && ((Explosion)(unit)).flameEffect())
            burnThis( true);
        else if
           ( unit.getClass() == Projectile.class 
                || unit.getClass() == Explosion.class)
             {
            
             }
        else
            hitBreak = 0;
            
        hP = hP - unit.getDamage();
        if( hP <= 0)
        {
            setState( 2);
            lane.removeUnit( this) ;
        }   
    }

    @Override
    public void act() {
        takeTarget(); 
        if( isBurning)
        {
            burn();
        }
        if( state == 0)
        {
            move();
            hitBreak =0;
        }
        if( target != null && state == 1)
        {
            if( hitBreak >= HIT_B/lane.speedModifier)
            {
                lane.addUnit( new Projectile( this));
                hitBreak = 0;
            }
            else
                hitBreak ++;         
            if(  target.getHP() <= 0)
            {
                target = null;
                setState( 0);
            }
        }
    }

    @Override
    public void draw(Graphics g) {
        if( state == 0)
        {
            g.setColor(Color.black);
            g.fillOval(((int)(laneLoc*size_modifier - size*size_modifier) ),(int) (y*lane.getYMod() - size*size_modifier), 2*(int)(size*size_modifier ), 2*(int)(size*size_modifier ));
        }
        if( state == 1)
        {
            g.setColor(Color.green);
            g.fillOval(((int)(laneLoc*size_modifier - size*size_modifier) ),(int) (y*lane.getYMod() - size*size_modifier), 2*(int)(size*size_modifier ), 2*(int)(size*size_modifier ));
            g.setColor(Color.black);
        }
    }

    @Override
    public boolean takeTarget() {
       priorityCount = 0;
       int priority = 0;
       ArrayList < Unit> targets = lane.targetsFor(this);
       if( targets.isEmpty())
       {
           state = 0;
           return true;  
       }
       Unit targetC = null;
       for( int i = 0; i < targets.size(); i++)
       {
           priority = 0;
           if( targetC != null && lane.targetsAround( targetC, 100) < lane.targetsAround( targets.get(i), 100))
               priority += IS_ZERGED;
           if( targets.get(i).getState() != 0)
               priority += IS_NOT_MOVING;
           if( targets.get(i).getHP() <= damage)
               priority += LOW_HP;
           if( targets.get(i).getClass() == Pikeman.class)
               priority += IS_PIKEMAN;
           if ( targets.get(i).getClass() == Saboteur.class)
               priority += IS_SABOTEUR;
           if ( targets.get(i).getClass() == Cavalry.class)
               priority += IS_CAVALRY;
           if ( targets.get(i).getClass() == Treb.class)
               priority += IS_TREB;
           if ( targets.get(i).getClass() == Swordsman.class)
               priority += IS_SWORDSMAN;
           if ( targets.get(i).getClass() == Keep.class)
               priority += IS_KEEP;
           if ( targets.get(i).getClass() == Wall.class)
               priority += IS_WALL;
           if ( targets.get(i).getClass() == Building.class)
               priority += IS_BUILDING;
           if ( targets.get(i).getClass() == Archer.class)
               priority += IS_ARCHER;
           if( targetC != null && Math.abs(targets.get(i).getLaneLoc() - laneLoc) < Math.abs(targetC.getLaneLoc() - laneLoc))
               priority = IS_NEAR;
           
           if( targetC == null || priority > priorityCount)
           {
               if( targets.get(i).getHP() > 0)
               {
                 targetC = targets.get(i);
                 state = 1;
               }
           }
           priority = 0;
       }
       target = targetC;
       return true;
    }
    
    public void burnThis( boolean a)
    {
        isBurning = a;
    }
    
    public void burn()
    {
        if( burnCount == MX_BC)
        {
            hP = hP - 1 - (int)(1*speed_modifier);
            burnCount = 0;
        }
        burnCount ++;

        if( hP <= 0)
        {
            setState( 2);
            lane.removeUnit( this) ;
        }   
    }
    
}
