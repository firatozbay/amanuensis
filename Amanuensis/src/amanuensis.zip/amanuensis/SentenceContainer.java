package amanuensis;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.util.ArrayList;
import javax.swing.JPanel;


class SentenceContainer extends JPanel implements Pressable{
	
	ArrayList<LetterBag> sentences;
	MyKeyListener key;
        
        int score;
        boolean state;
        
     
        
	public SentenceContainer()
	{
                setLayout(new GridLayout(4,1,15,15));
                //setLayout(new FlowLayout());
		sentences = new ArrayList<LetterBag>();
		
                score = 0;
                
                setBackground(Color.white);
                
		this.setFocusable( true);
                
                
                addLetterBag( "F");
                addLetterBag( "S");
                addLetterBag( "T");
                addLetterBag( "F");
                
                addLetterBag( "f");
                addLetterBag( "f");
                addLetterBag( "s");
                addLetterBag( "g");
               
                
                setOpaque(true);
		setVisible(true);
	}
	
	public void addLetterBag(String s)
	{
		sentences.add(new LetterBag(s, sentences.size()<1));
		if(sentences.size()<5)
			add(sentences.get(sentences.size()-1));
	}
        
        public int getScore()
        {
            return score;
        }
	
        @Override
	public void update(Integer n)
	{         
            state = false;
            if( !sentences.isEmpty())
            {
                sentences.get(0).update(n);

                if(sentences.get(0).allCorrect())
                {

                    remove(sentences.get(0));
                    sentences.remove(sentences.get(0));
                    score++;
                    state = true;
 

                    if( sentences.isEmpty())
                        addLetterBag("There are no quotes left");
                    else if( sentences.size() < 5 )
                        add( sentences.get(sentences.size()-1));
                    else
                        add( sentences.get(3));
                    sentences.get(0).setActive(true);
                }
            }		
	}
        
        public void paintComponent(Graphics g)
        {
            super.paintComponent(g);
        }
        
        public void setState( boolean a) // true if unit spawner false if not
        {
            state = a;
        }
        
        public boolean getState()
        {
            return state;
        }
        
        public void setScore( int a)
        {
            score = a;
        }
        

    
}
