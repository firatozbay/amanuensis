/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package amanuensis;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

/**
 *
 * @author Magus
 */
public class Swordsman extends LivingUnit{
    
    /* state 0 = move
       state 1 = attack
       state 2 = die
    */
    
     final static double DX = 3;
     final static double RANGE = 45;
     final static double SIZE = 35;
     final static int DAMAGE = 50;
     final static int BASE_HP = 400;
     final static int HIT_B = 20;
     
     // priority ( higher is better) 
     final static int LOW_HP = 6; // if hp is lower than or equal to 50
     final static int IS_PIKEMAN = 4; // if it is pikeman
     final static int IS_SABOTEUR = -100; // never attack one wont do any good
     final static int IS_CAVALRY = 2; // Should eliminate  before the next charge
     final static int IS_TREB = 4; // dangerous 
     final static int IS_ARCHER = 1;
     final static int IS_SWORDSMAN = 0;
     final static int IS_KEEP = 0;
     final static int IS_WALL = 0;
     final static int IS_BUILDING = 0;
     static BufferedImage img;
     static ImageLoader loader;
     static ImageModificator mod;

     
     int hitBreak;
     int priorityCount;
     Unit nearestHostile;
     
    public Swordsman( Lane lane, boolean isHost, int level)
    {
      super( lane, isHost, level);
      setLevel( level);
      hitBreak = HIT_B;
      super.hP = BASE_HP;
      super.range = RANGE;
      super.size = SIZE;
      super.state = 0;
      super.damage = DAMAGE + level*10;
      super.size_modifier = lane.getMod();
       if( isHost)
        {
             setLaneLoc( lane.getStart());
             super.dx = DX*lane.speedModifier;
        }
          
         else
        {
            setLaneLoc( lane.getEnd());
            super.dx = -DX*lane.speedModifier;
        } 
        loader = new ImageLoader("res/png_example.png");
        img = loader.getIMG();
        mod = new ImageModificator();
        img = mod.resize(img, 6*size*size_modifier/img.getWidth());
    }

    @Override
    public boolean takeTarget() {
       priorityCount = 0;
       int priority = 0;
       ArrayList < Unit> targets = lane.targetsFor(this);
       if( targets.isEmpty())
       {
           state = 0;
           return true;  
       }
       Unit targetC = null;
       for( int i = 0; i < targets.size(); i++)
       {
           priority = 0;
           if( targets.get(i).getHP() <= damage)
               priority += LOW_HP;
           if( targets.get(i).getClass() == Pikeman.class)
               priority += IS_PIKEMAN;
           if ( targets.get(i).getClass() == Saboteur.class)
               priority += IS_SABOTEUR;
           if ( targets.get(i).getClass() == Cavalry.class)
               priority += IS_CAVALRY;
           if ( targets.get(i).getClass() == Treb.class)
               priority += IS_TREB;
           if ( targets.get(i).getClass() == Swordsman.class)
               priority += IS_SWORDSMAN;
           if ( targets.get(i).getClass() == Keep.class)
               priority += IS_KEEP;
           if ( targets.get(i).getClass() == Wall.class)
               priority += IS_WALL;
           if ( targets.get(i).getClass() == Building.class)
               priority += IS_BUILDING;
           if ( targets.get(i).getClass() == Archer.class)
               priority += IS_ARCHER;
         
           
           if( targetC == null || priority > priorityCount)
           {
               if( targets.get(i).getHP() > 0)
               {
                 targetC = targets.get(i);
                 state = 1;
                 priorityCount = priority;
               }
           }
           priority = 0;
       }
       target = targetC;
       return true;
    }
    
    @Override
    public void damagedBy(Unit unit) {
        hP = hP - unit.getDamage();
        if( hP <= 0)
        {
            setState( 2);
            lane.removeUnit( this) ;
        }
    }

    @Override
    public void act() {
        takeTarget();       
        if( state == 0)
           move();
        if( target != null && state == 1)
        {
            if( hitBreak >= HIT_B/lane.speedModifier)
            {
                target.damagedBy( this);
                hitBreak = 0;
            }
            else
                hitBreak ++;         
            if(  target.getHP() <= 0)
            {
                target = null;
                setState( 0);
            }
        }  
    }

    @Override
    public void draw(Graphics g) {
        BufferedImage img1 = img;
        if( y != lane.getYofLane() && laneLoc < lane.DEFORMATION_LOC + lane.GAP)
            img1 = mod.rotate( img, (lane.GAP + lane.DEFORMATION_LOC - laneLoc)*size_modifier , (lane.getYofLane() - lane.getY(laneLoc))*lane.getYMod());
        if( y != lane.getYofLane() && laneLoc > lane.TOTAL_L -  lane.DEFORMATION_LOC - lane.GAP)
            img1 = mod.rotate( img,(+laneLoc -lane.TOTAL_L + lane.GAP +lane.DEFORMATION_LOC)*size_modifier, ((-lane.getYofLane() + lane.getY(laneLoc))*lane.getYMod()));
            
        g.setColor(Color.black);
            g.drawImage( img1, ((int)(laneLoc*size_modifier - img1.getWidth()/2) ),(int) (y*lane.getYMod() - img1.getHeight()/2), null);
            System.out.println( img);
        

        {
            g.setColor(Color.blue);
            g.fillOval(((int)(laneLoc*size_modifier - size*size_modifier) ),(int) (y*lane.getYMod() - size*size_modifier), 2*(int)(size*size_modifier ), 2*(int)(size*size_modifier ));
            g.setColor(Color.black);
        }
    }
}

    
