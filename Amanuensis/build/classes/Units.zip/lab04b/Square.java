package lab04b;
/*
 * Aras Heper
 * pretty �uch everything comes from rectangle but w = h
 */


public class Square extends Rectangle
{
	public Square( double s )
	{
		super( s , s );
	}
	
	public String toString()
	{
		return  "Square /" + ", selected?:" + getSelected() + ", location (" + x + ", " + y + ")" ;
	}
	
}