public interface Locatable{
	
	public double getX();
	
	public double getY();
	
	public void setLocation( double xx, double yy);
}