/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab04b;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;


/**
 *
 * @author Magus
 */
public class Lab04b {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ActionListener circleDrawer;

         
        
        JFrame frame = new JFrame();
        
        frame.setBounds( 0, 0, 550, 570);
        frame.setResizable(false);
        ShapesGame a = new ShapesGame();
        frame.add( a );
        frame.setVisible(true);
        
        
        
    }
}