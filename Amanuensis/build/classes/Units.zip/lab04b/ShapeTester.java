package lab04b;
import java.util.Scanner;
/**
 * @(#)ShapeTester.java
 *
 * Testing menu for Shapes
 * @Aras Heper
 * @version 1.00 2014/3/14
 *
 * ATENTION! ALL SHAPES LOCATION IS AROUND (0,0) THERE IS NO OPTION IN THE MENU TO CHANGE THAT
 * METHOD TAG FOR CHANGING IS setLocation( double newX, double newY ) FOR ALL SHAPE OBJECTS
 */
public class ShapeTester {


    public static void main(String[] args)
    {
        Scanner scan = new Scanner( System.in );
        ShapeContainer alpha = new ShapeContainer();
        int c = 0;

        do
        {
        	System.out.println(" choice? \n-1 for exit  \n1 for adding rectangle \n2 for square \n3 for circle \n4 for printing the list \n5 for finding first shape containing the point given by the user and selecting it \n6 for remove all selected shapes.");
        	c = scan.nextInt();
        	if( c == 1)
        	{
        		System.out.println(" enter w,h " );
        		double w = scan.nextDouble();
        		double h = scan.nextDouble();
        		Rectangle aa = new Rectangle( w,h );
        		alpha.addShape( aa );
        	}
        	
        	if( c == 2)
        	{
        		System.out.println(" enter side length" );
        		double s = scan.nextDouble();
        		Square aa = new Square( s );
        		alpha.addShape( aa );

        	}
        	
        	if( c == 3)
        	{
        		System.out.println(" radius " );
        		double r = scan.nextDouble();
        		Circle aa = new Circle( r );
        		alpha.addShape( aa );
                        System.out.println(" location? " );
                        double x = scan.nextDouble();
                        double y = scan.nextDouble();
                        aa.setLocation(x, y);
        	}
        	
        	if( c == 4)
        	{
        		System.out.println(alpha + " , " + alpha.overlapingCircleNumber());
                        
        	}
        	
        	if( c == 5)
        	{
        		System.out.println(" enter x,y " );
        		double x = scan.nextDouble();
        		double y = scan.nextDouble();
        		System.out.println(alpha.firstContShape( x,y ));
        	}
        	
        	if( c == 6 )
        	{
        		alpha.removeSelecteds();
        	}
        	
        }while( c != -1);
    }
}
