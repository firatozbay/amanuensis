package lab04b;
/* can only stand like this;
 *  ______________
 * |              |
 * |              |
 * |		  |
 * |______________|
 *
 * selectability comes from properity state(boolean) inherently false, can be changed by methods
 * ArasHeper
 **/
public class Rectangle extends Shape implements Selectable
{
	//props
	boolean state; 
	public double w;
	public double h;
        
	//cons
	public Rectangle( double w, double h )
	{  
            state = false;
            this.w = w;
            this.h = h;
	}
	
	//meth
	public double getArea()
	{
            return w*h;
	}
	
	public String toString()
	{
            return "Rectangle /" + ", selected?:" + getSelected() + ", location (" + x + ", " + y + ")" ;
	}
	
	public Shape contains( double x, double y)
	{
            double distanceX;
            double distanceY;
            distanceX = Math.abs( x - getX() );
            distanceY = Math.abs( y - getY() );
            if( distanceX <= w/2 && distanceY <= h/2 )
            {
                    state = true;
                    return this;
            }
            return null;
	}
	
	public void setSelected( boolean a )
	{
            state = a;
 	}
 	
 	public boolean getSelected()
	{
            return state;
 	}
}