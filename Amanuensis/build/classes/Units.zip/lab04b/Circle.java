package lab04b;

import java.awt.Graphics;

/*
 *Aras Heper
 *selectability comes from properity state(boolean) inherently false, can be changed by methods
 *
 */
public class Circle extends Shape implements Selectable, Drawable
{
    //props
    public double radius;
    boolean state;
    //cons
    public Circle( double r )
    {
            state = false;
            radius = r;
    }

    //meth
    public double getArea()
    {
            return Math.PI*radius*radius;
    }

    public String toString()
    {
            return "Circle /" + ", selected?:" + getSelected() + ", location (" + x + ", " + y + ")" ;
    }

    public Shape contains( double x, double y)
    {
            double distance;
            distance = Math.sqrt( Math.abs( (this.x - x)*(this.x - x) + (this.y - y)*(this.y - y) ) );
            if( distance <= radius)
            {
                    state = true;
                    return this;
            }
            return null;
    }

    public void setSelected( boolean a )
    {
            state = a;
    }

    public boolean getSelected()
    {
            return state;
    }

    @Override
    public void draw(Graphics g) {
      double X = x - radius;
      double Y = y - radius;
      g.drawOval( (int) X, (int) Y, (int) radius*2, (int) radius*2);  
    }
    
    public double getRadius()
    {
        return radius;
    }
    
}