package lab04b;
import java.awt.*;
public interface Drawable {
   public void draw( Graphics g);
}