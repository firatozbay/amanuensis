
package lab04b;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
/**
 *
 * @author Aras Heper
 * ShapesCanvas
 * Mouse Listener = only mouse relased meth : finds and removes if there is a shape there
 * deactivate : locks the game, through regulative variable close
 * 
 */
public class ShapesCanvas extends JPanel implements MouseListener{
    
    ShapeContainer container;
    boolean close;
    int process;
    
    public ShapesCanvas( ShapeContainer a )
    {  
        super();
        Dimension d = new Dimension( 500, 500 );
    	setPreferredSize( d );
        container = a;  
        addMouseListener( this ); 
        close = false;
    }
    
    @Override
    public void paintComponent( Graphics g) 
    {
       super.paintComponent(g);
       container.draw( g);   
    }
    
    public void deactivate()
    {
        close = true;
    }
    
    @Override
    public void mouseClicked(MouseEvent e) {       
    }

    @Override
    public void mousePressed(MouseEvent e) {}

    @Override
    public void mouseReleased(MouseEvent e) {
        int x = e.getX();
        int y = e.getY();
        // if the panel deactivated then wont do anything
        if ( container.firstContShape( x , y ) != null && close != true )
        {
            System.out.println(container.firstContShape( x , y ).getX());
            System.out.println(container.firstContShape( x , y ).getY());
            container.removeSelecteds();
            repaint();
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {}

    @Override
    public void mouseExited(MouseEvent e) {}
}
