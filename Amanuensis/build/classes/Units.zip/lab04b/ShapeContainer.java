package lab04b;
import java.awt.Graphics;
import java.util.ArrayList;
/* Aras Heper
 * contains shape objects, most usefull for Shapes
 * firstContShape( x , y ) = First shape containing point ( x , y ); returns first shape in the bag, containing this point and sets it selectable
 * removeSelecteds() = removes all selected shapes 
 */
public class ShapeContainer implements Drawable{
	//prop
    ArrayList bag;
	//cons
    public ShapeContainer()
    {
            bag = new ArrayList<Shape>();
    }

	//meth
    public void addShape( Shape p )
    {
            bag.add( p );
    }
	
    public double getArea()
    {
            double total = 0;
            for( int i = 0; i < bag.size(); i++)
            {
                    total =+ ((Shape)bag.get(i)).getArea();
            }
            return total;
    }
        
    @Override
    public String toString()
    {
            String a = " ";
            for( int i = 0; i < bag.size(); i++)
            {
                    a += bag.get(i) + ", area: " +  ((Shape)bag.get(i)).getArea() + " \n ";
            }
            return a;
    }
	
    public void removeSelecteds() // removes all selected shapes
    {
            for( int i = 0; i < bag.size(); i++)
            {
                if( ((Selectable)bag.get(i)).getSelected())
                bag.remove(i);
            }
    }
	
    public Shape firstContShape( double xx , double yy ) // returns first selectable shape 
    {
            for( int i = 0; i < bag.size(); i++)
            {
                if( ((Selectable)bag.get(i)).contains( xx , yy ) != null )
                    return (Shape) bag.get(i);
            }
            return null;       
    }

    @Override
    public void draw(Graphics g) 
    {
        for( int i = 0; i < bag.size(); i++)
        {
            if ( bag.get(i) instanceof Circle)
            {
               ((Circle) bag.get(i)).draw(g);
            }
        }
    }
    
    public int getSize()
    {
        return bag.size();
    }
    
    public Shape getShape( int i )
    {
        return (Shape)bag.get(i);
    }
    
    public int overlapingCircleNumber()
    {
        int count;
        count = 0;      
        for( int i = 0; i < getSize(); i++)
        {
         boolean change = false;
         for( int ii = 0; ii <getSize() && change == false; ii++)
         {
           Shape l = getShape(i);
           Shape ll = getShape(ii);
           double distance;
           double lx = l.getX();
           double ly = l.getY();
           double llx = ll.getX();
           double lly = ll.getY();                   
           if ( l != ll)                       
           {   
               distance = Math.sqrt( Math.abs( lx - llx)*(lx - llx) + (ly - lly)*(ly -lly) );
               if ( (((Circle)l).getRadius() + ((Circle)ll).getRadius()) > distance)
               {     
                   count += 1;
                   change = true;
               }                         
           } 
         }
       }
        return count;
    }
}