
package lab04b;
import java.awt.*;
import static java.awt.Adjustable.VERTICAL;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Arrays;
import javax.swing.*;

/**
 *
 * @author Magus
 * Shapes Game
 * Uses ShapeCanvas
 * 
 * The game places randomly sized 
 * circles at random locations on the screen, one by one. 
 * Clicking on a circle removes it from the screen. The game consist of five rou-
 * nds. During each round ten circles are added to the display. Points are award-
 * ed at the end of each round, one point for each circle that is not overlapped
 * by any other circle.
 * 
 * updateTimer(); private method regulates time schedule
 */
public class ShapesGame extends JPanel {
    
    //some static values
    final static int SHAPE_BASE_SPAWN_SPEED = 100;
    final static int BASE_TURN_DELAY = 1000;
    final static int FREEZE = 300; // not used
    final static int SHAPE_SPAWN_DELAY_FOR_ROUND_LOOPCOUNT = 3;
    final static int MAX_TURN = 6;
    final static int MAX_NUMBER_OF_CIRCLES = 10;
    // UI members
    ShapesCanvas canvas;
    JLabel score;
    JLabel turns;
    JProgressBar turnProcess;
    // administrating and UI regulating values
    int scoreNo;
    int turnNo;
    int gardenIndex;
    int count;
    int speedModifier;
    //2 timers, both for spawning and turn-passing
    Timer timer;
    Timer timerTurn;
    Timer delayTimer;
    //UI texts
    String scoreOut;
    String turnOut;
    //administrive boolean value, regulates turn passsing process
    // color plate
    Color c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11;
    ArrayList < Color > garden;   
   
    //CONSTRUCTER
    public ShapesGame( )
    {    
        // Administrive Values
        count = 0;
        scoreNo = 0;
        turnNo = 1;
        gardenIndex = 0;
        speedModifier = 6; // regulates vhange in speed!!!!! unused, missing parts in the code
        
        // consructs colors ( variations of yellow-red)
        c1 = new Color( 0, 0, 0);
        c2 = new Color( 255, 205, 0);
        c3 = new Color( 255, 185, 0);
        c4 = new Color( 255, 165, 0);
        c5 = new Color( 255, 140, 0);
        c6 = new Color( 255, 125, 0);
        c7 = new Color( 255, 100, 0);
        c8 = new Color( 255, 90, 0);
        c9 = new Color( 255, 55, 0);
        c10 = new Color( 255, 30, 0);
        c11 = new Color( 255, 10, 0);
        
        // adds colors to color plate
        garden = new ArrayList<Color>( Arrays.asList( c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11));
        
        // constructs panel
        setLayout( null); // everything placed manually
        setBounds( 0, 0, 550, 550); 
        
        // constructs ShapeCanvas
        canvas = new ShapesCanvas( new ShapeContainer() );
        canvas.setBounds( 0, 0, 500, 500);        
        canvas.setBackground( garden.get(gardenIndex));
        
        // init. texts
        scoreOut = " Score: " + scoreNo;
        turnOut = "" + turnNo;       
        
        // adds scoreboard
        score = new JLabel();
        score.setText( scoreOut );
        score.setBounds(0, 500, 500, 50);
        score.setOpaque(true);
        
        // adds turnNumber text
        turns = new JLabel( );
        turns.setText( turnOut );
        turns.setBounds( 500, 500, 50, 50);
        turns.setOpaque(true);
        
        // adds process bar
        turnProcess = new JProgressBar(1,6);
        turnProcess.setOrientation(VERTICAL);
        turnProcess.setBounds(500, 0, 50, 500);
        turnProcess.setValue(1);  
        
        // sry adds here :D
        add( canvas);
        add( turnProcess);
        add( score);
        add( turns);
        
        // starts timers
        updateTimer();
    }
    
    @Override
   public void paintComponent(Graphics g) 
    {
        canvas.paintComponent(g);
    }
   
   //this method regulates 2 independent timer schedules
   private void updateTimer()
   {
        timer = new Timer( SHAPE_BASE_SPAWN_SPEED * speedModifier, new ActionListener() {
            public void actionPerformed(ActionEvent e) 
            {
                // translation: if the turn has not ended yet |or| if it has delayed enough already
                //stops and lock if its max turn
                if( turnNo == MAX_TURN)
                {
                    scoreOut = " Game Over! Your Score: " + scoreNo;
                    score.setText( scoreOut);
                    score.updateUI();
                    forceStop();

                }
                //if not ordinary schedule
                if( turnNo != MAX_TURN && count != MAX_NUMBER_OF_CIRCLES)
                {
                    // caunting no of shapes on the field
                    count += 1;
                    // reasigning administrive values
                    gardenIndex++;
                    // painting stuff and other UI construction
                    canvas.setBackground( garden.get(gardenIndex));
                    Circle c  = new Circle( Math.random()*100 );
                    c.setLocation( ((int)(Math.random()*500 - 1)), ((int)(Math.random()*500 - 1)) );
                    canvas.container.addShape( c);
                    java.awt.Toolkit.getDefaultToolkit().beep(); 
                    canvas.repaint();                        
                }                                   
            }
        });
        timer.start();
        
         timerTurn = new Timer( MAX_NUMBER_OF_CIRCLES*SHAPE_BASE_SPAWN_SPEED * speedModifier + 500, new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        // administrive values reinit.
                        
                        turnNo += 1; 
                        delay();
                        gardenIndex =0;
                        int totalCircleNumber = canvas.container.getSize();
                        int overlaps = canvas.container.overlapingCircleNumber();                       
                        scoreNo += totalCircleNumber - overlaps;
                        // texts recon.
                        scoreOut = " Score: " + scoreNo;
                        turnOut = "" + turnNo;
                        // process bar                       
                        turnProcess.setValue( turnNo);
                        // labels                                   
                        turns.setText( turnOut);
                        turns.updateUI();
                        score.setText( scoreOut);
                        score.updateUI(); 
                        speedModifier --;
                        // in case of erros
                        if( speedModifier == 1 )
                        {
                            speedModifier = 2;
                        }
                        //starts delay schedule
                        
                        // stops the schedule if its max turn
                        if( turnNo == MAX_TURN)
                        {
                            timerTurn.stop();
                        }
                    }
                 });
        timerTurn.start();       
   }
   
   // delays 2 other timers
   public void delay()
   {
        delayTimer = new Timer( 1500 , new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println( speedModifier );
                timer.stop();
                timerTurn.stop();               
                countinue();                	
                }                   	
            });
        delayTimer.start();
   }
   
   //stops the freeze and cleans any regulations for the next turn
   public void countinue()
   {
       delayTimer.stop();
       count = 0;
       updateTimer();
   }
   
   //game ends
   public void forceStop()
   {
       delayTimer.stop();
       timer.stop();
       timerTurn.stop();
       canvas.deactivate();
   }
}


