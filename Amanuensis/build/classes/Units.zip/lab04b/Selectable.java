package lab04b;
public interface Selectable {
	
	public boolean getSelected();
	
	public void setSelected( boolean a );
	
	public Shape contains( double x , double y );
}