package lab04b;
/* All Shapes' middle point is ( 0,0 ) !!inherently!!. can be changed by setLocation method
 * abs. getArea() calculates area for subclasses
 * getX & getY returns location
 * setLocation modifys. location
 * Aras heper
 * Hierarchy Shape(Locatable) > SelectableShape(Selectable) > Circle
 * Hierarchy Shape(Locatable) > SelectableShape(Selectable) > Rectangle > Square
 **/
public abstract class Shape implements Locatable{
	//prop
    	public double x;
 	public double y;
	//cons

	//meth
	public abstract double getArea();
	public double getX()
	{
		return x;
	}
	public double getY()
	{
		return y;
	}
	public void setLocation( double xx, double yy)
	{
		x = xx;
		y = yy;
	}
}